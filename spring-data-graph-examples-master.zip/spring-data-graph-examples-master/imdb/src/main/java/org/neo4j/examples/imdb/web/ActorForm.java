package org.neo4j.examples.imdb.web;

public class ActorForm {
    private String name;

    public void setName(final String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
