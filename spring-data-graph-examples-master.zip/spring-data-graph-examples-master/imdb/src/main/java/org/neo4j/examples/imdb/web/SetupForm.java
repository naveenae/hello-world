package org.neo4j.examples.imdb.web;

public class SetupForm {
}
