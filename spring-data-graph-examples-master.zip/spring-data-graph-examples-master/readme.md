This repository contains examples for using the Spring Data Graph Library, 
currently the examples all use the 1.0.0.M4 release.

*  HelloWorlds is a simple application showing the basic setup, annotations and usage
*  Imdb is a graph based webapp for a movie - actor database using an older spring-web stack and an example for in graph indexes
*  Myrestaurants-Social is a spring-roo generated and then modified restaurant - rating webapp that was extended using a social graph with ratings and recommendations
