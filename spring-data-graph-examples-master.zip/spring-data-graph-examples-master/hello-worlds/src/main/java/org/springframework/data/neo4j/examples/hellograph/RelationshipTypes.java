package org.springframework.data.neo4j.examples.hellograph;

public abstract class RelationshipTypes
{
    public static final String REACHABLE_BY_ROCKET = "REACHABLE_BY_ROCKET";
}
