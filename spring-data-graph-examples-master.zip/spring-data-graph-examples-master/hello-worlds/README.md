Hello Worlds
============

A simple Spring Data Graph example with just enough code to
do something that works.

Build and Run
-------------

`mvn clean package exec:java`
